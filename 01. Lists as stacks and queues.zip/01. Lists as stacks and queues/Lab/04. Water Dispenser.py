from collections import deque

if __name__ == "__main__":
    persons = deque()
    command = input()
    while not command == 'Start':
        name = input()
        


# create a queue
# read command
# while command != Start:
#    append to queue and read new command
# read command
# while command != End:
#    if command == refill: increase litters
#    else: print message depending on the available litters
# print left litters
